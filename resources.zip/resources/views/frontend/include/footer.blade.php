  <footer class="page-footer footer-centered text-center">
        <div class="footer-content">
          <div class="container">
            <!--Brand--><a class="brand" href="index.html"><img class="brand-logo-dark" src="images/logo-default-311x70.png" alt="" width="155" height="35"/><img class="brand-logo-light" src="images/logo-inverse-311x70.png" alt="" width="155" height="35"/></a>
            <p class="big">We believe in Simple, Creative & Flexible Design Standards.</p>
            <ul class="list-inline">
              <li class="list-inline-item"><a class="fa-facebook" href="#"></a></li>
              <li class="list-inline-item"><a class="fa-pinterest-p" href="#"></a></li>
              <li class="list-inline-item"><a class="fa-twitter" href="#"></a></li>
              <li class="list-inline-item"><a class="fa-google-plus" href="#"></a></li>
              <li class="list-inline-item"><a class="fa-instagram" href="#"></a></li>
            </ul>
          </div>
        </div>
        <div class="copyright">
          <div class="container">
            <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"></span><span>&nbsp;</span><span>Modicate</span><span>&nbsp;</span><span>All Rights Reserved</span><span>.&nbsp;</span><a href="terms-of-service.html">Privacy Policy</a></p>
          </div>
        </div>
      </footer>