<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
    <!--Site Title-->
    <title>Rightway Future</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css"
        href="//fonts.googleapis.com/css?family=Pacifico%7CLato:400,100,100italic,300,300italic,700,400italic,900,700italic,900italic%7CMontserrat:400,700">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
    .ie-panel {
        display: none;
        background: #212121;
        padding: 10px 0;
        box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
        clear: both;
        text-align: center;
        position: relative;
        z-index: 1;
    }

    html.ie-10 .ie-panel,
    html.lt-ie-10 .ie-panel {
        display: block;
    }
    </style>
</head>

<body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img
                src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820"
                alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a>
    </div>
    <div class="preloader">
        <div class="preloader-body">
            <div class="cssload-container">
                <div class="cssload-speeding-wheel"></div>
            </div>
            <p>Loading...</p>
        </div>
    </div>
    <!--The Main Wrapper-->
    <div class="page">
        @include('admin.internal_header')

        <!-- Breadcrumbs-->
        <section class="section section-sm text-center">
            <div class="container isotope-wrap">
                <div class="row">
                    <div class="col-12">
                        <h1>Gallery</h1>
                        <div class="lead">Deliverables users, seamless beta-test implement tag.</div>
                    </div>
                    <div class="col-12 margin-1">
                        <div class="isotope-filters isotope-filters-horizontal">
                            <ul class="inline-list button-group-isotope isotope-filters-list" id="isotope-filters">
                                <li><a class="active button button-default button-xs round-xl" href="#"
                                        data-isotope-filter="*" data-isotope-group="gallery">All</a></li>
                                <li><a class="button button-default button-xs round-xl" href="#"
                                        data-isotope-filter="type-1" data-isotope-group="gallery"> Type 1</a></li>
                                <li><a class="button button-default button-xs round-xl" href="#"
                                        data-isotope-filter="type-2" data-isotope-group="gallery"> Type 2</a></li>
                                <li><a class="button button-default button-xs round-xl" href="#"
                                        data-isotope-filter="type-3" data-isotope-group="gallery"> Type 3</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="isotope" data-isotope-layout="masonry" data-isotope-group="gallery"
                    data-lightgallery="group">
                    <div class="row">
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-1">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-1_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-10.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-1">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-2_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-14.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-1">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-3_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-18.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-2">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-4_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-11.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-2">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-6_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-19.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-2">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-5_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-15.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-3">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-7_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-12.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-3">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-8_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-16.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-3">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-9_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-20.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-3">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-2_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-17.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-3">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-1_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-13.jpg" alt="" />
                            </div>
                        </div>
                        <div class="col-6 col-md-6 col-lg-4 isotope-item" data-filter="type-3">
                            <div class="thumbnail-variant-2 thumbnail-4 text-center"><a
                                    href="images/gallery-3_original.jpg" data-lightgallery="item"><img
                                        src="images/gallery-21.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!--Footer-->
        @include('admin.footer')
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!--Scripts-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>