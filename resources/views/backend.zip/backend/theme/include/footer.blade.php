  <footer class="main-footer">
      <strong>Copyright &copy; 2021-2022 <a href="#">Rightway Future</a>.</strong>
      All rights reserved.
      <div class="float-right d-none d-sm-inline-block">
          <b>Version</b> 1.0 Beta
      </div>
  </footer>